﻿WAPOW GRID SCREENSAVER  -  version 1.0
=====================================

An 80s neon screensaver: a chrome WAPOW logo over a synthwave grid, with a
time-attack Evo 8 cruising through a glowing, GPU-rendered airflow field that
reacts to its wing, diffuser and wheels.

Free to download and share.


REQUIREMENTS
------------
- Windows 10 or Windows 11, 64-bit
- Microsoft Edge WebView2 Runtime. Built into Windows 11 and already installed
  on almost every Windows 10 PC. If the screensaver shows a black screen, get it
  free from Microsoft: https://developer.microsoft.com/microsoft-edge/webview2/
- A graphics card with WebGL2 (any card from the last 10 years). Older or slower
  cards are handled automatically: see "Graphics quality" below.
- Internet is optional. Without it the WAPOW lettering uses a plain bold font;
  everything else works offline.


INSTALL
-------
1. Unzip the download.
2. Move WapowGrid.scr to a folder you'll keep, for example Documents.
   (Windows remembers where it is, so don't install it straight from Downloads
   if you clean that folder out.)
3. Right-click WapowGrid.scr and choose "Install".
4. Screen Saver Settings opens with WAPOW Grid selected. Pick how many minutes
   to wait, then click OK.

Windows may warn you the first time ("Windows protected your PC"). This happens
with screensavers that aren't sold through a store. Click "More info", then
"Run anyway".


SETTINGS
--------
In Screen Saver Settings, click "Settings..." to choose:
- Graphics quality: Auto (recommended), High, Medium or Low.
  Auto starts at High and steps down if your PC can't keep a smooth frame rate.
  The current level shows in the bottom-left corner ("GFX AUTO - HIGH").
- Car neon colour: cyan, magenta, yellow, orange, green, or random each time.
- Car overtakes: how often the car drops back and passes the camera.

To exit the screensaver, move the mouse, click, or press any key.


UNINSTALL
---------
1. In Screen Saver Settings, choose "(None)" and click OK.
2. Delete WapowGrid.scr.
3. Optional clean-up: delete the folder %LOCALAPPDATA%\WapowGrid and the
   registry key HKEY_CURRENT_USER\Software\WapowGrid (your settings).


CREDITS
-------
Car model: "Mitsubishi Lancer Evo 8 Time attack Xtreme" by DRIVER-FIRE,
licensed under Creative Commons Attribution 4.0 (CC BY 4.0).
  https://sketchfab.com/3d-models/mitsubishi-lancer-evo-8-time-attack-xtreme-aeba48d6449041b48a60434edffef970
  https://creativecommons.org/licenses/by/4.0/
The model's author credits Hamlink for the original body kit, Speedude
Performance for the base interior, and S.D Jackson for the original wheels.
Changes made for this screensaver: hidden interior and internal parts removed,
the trunk emblem removed, geometry simplified and repainted, wheels set to spin
on their own axles.

Fonts: Audiowide, VT323 and Share Tech Mono, from Google Fonts (SIL Open Font
License), loaded online when available.

Built with the Microsoft Edge WebView2 SDK. See THIRD-PARTY-NOTICES.txt.

Mitsubishi and Lancer Evolution are trademarks of Mitsubishi Motors
Corporation. This screensaver is a fan creation and is not affiliated with,
sponsored or endorsed by Mitsubishi Motors.

This software is provided "as is", without warranty of any kind.
